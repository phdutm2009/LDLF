from numpy import loadtxt

numberOfNodes = '1m'
mu = '0.6'

network= loadtxt(numberOfNodes+"/"+mu+"/network.dat", comments="#", delimiter="\t", unpack=False)
neighborList = {}

for i in network:
    neighborList.setdefault(i[0],[]).append(i[1])


with open(numberOfNodes+"/"+mu+"/Neighboring_List.txt", 'w', encoding="utf-8") as f:
    for key, value in neighborList.items():
        for v in value:
            f.write('%s \t' % (int(v)-1))
        f.write('\n')

